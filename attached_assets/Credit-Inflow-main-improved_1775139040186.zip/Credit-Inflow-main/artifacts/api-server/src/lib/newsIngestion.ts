import { logger } from "./logger";

const NEWS_API_KEY = process.env.NEWS_API_KEY;
const NEWS_API_URL = "https://newsapi.org/v2/everything";

const CREDIT_KEYWORDS = [
  "credit markets",
  "leveraged loans",
  "high yield bonds",
  "credit rating downgrade",
  "bond default",
  "corporate debt",
  "CLO",
  "credit spread",
  "junk bonds",
  "loan syndication",
  "bankruptcy",
  "debt restructuring",
  "fixed income",
  "bond yields",
];

const RSS_CREDIT_KEYWORDS = [
  ...CREDIT_KEYWORDS,
  "bonds",
  "yield",
  "default",
  "debt",
  "rating",
  "downgrade",
  "spread",
  "credit",
  "interest rate",
  "Federal Reserve",
  "Fed",
  "treasury",
  "loan",
  "refinancing",
  "maturity",
  "coupon",
  "covenant",
  "distressed",
  "investment grade",
  "speculative",
  "Moody",
  "Fitch",
  "S&P",
];

const LOW_QUALITY_PATTERNS = [
  /stock picks?/i,
  /crypto/i,
  /personal finance/i,
  /mortgage tips?/i,
  /ETF inflows?/i,
  /top stocks?/i,
  /dividend/i,
];

export interface RawArticle {
  title: string;
  source: string;
  publishedAt: Date;
  url: string;
  rawContent: string | null;
}

function normalizeUrl(url: string): string {
  try {
    const parsed = new URL(url);
    parsed.hash = "";
    parsed.searchParams.delete("utm_source");
    parsed.searchParams.delete("utm_medium");
    parsed.searchParams.delete("utm_campaign");
    return parsed.toString();
  } catch {
    return url;
  }
}

function normalizeTitle(title: string): string {
  return title.toLowerCase().replace(/[^a-z0-9 ]/g, " ").replace(/\s+/g, " ").trim();
}

function looksLowQuality(title: string, body: string | null): boolean {
  const text = `${title} ${body ?? ""}`;
  return LOW_QUALITY_PATTERNS.some((pattern) => pattern.test(text));
}

function isCreditRelated(title: string, body: string | null): boolean {
  const haystack = `${title} ${body ?? ""}`.toLowerCase();
  return RSS_CREDIT_KEYWORDS.some((kw) => haystack.includes(kw.toLowerCase()));
}

function dedupeArticles(input: RawArticle[]): RawArticle[] {
  const byUrl = new Map<string, RawArticle>();
  const byTitle = new Map<string, RawArticle>();

  for (const article of input) {
    const normalizedUrl = normalizeUrl(article.url);
    const normalizedTitle = normalizeTitle(article.title);
    const existingByUrl = byUrl.get(normalizedUrl);
    const existingByTitle = byTitle.get(normalizedTitle);
    const candidate = { ...article, url: normalizedUrl };

    if (existingByUrl) {
      if ((candidate.rawContent?.length ?? 0) > (existingByUrl.rawContent?.length ?? 0)) {
        byUrl.set(normalizedUrl, candidate);
      }
      continue;
    }

    if (existingByTitle && Math.abs(existingByTitle.publishedAt.getTime() - candidate.publishedAt.getTime()) < 1000 * 60 * 60 * 18) {
      if ((candidate.rawContent?.length ?? 0) > (existingByTitle.rawContent?.length ?? 0)) {
        byTitle.set(normalizedTitle, candidate);
        byUrl.set(normalizedUrl, candidate);
      }
      continue;
    }

    byUrl.set(normalizedUrl, candidate);
    byTitle.set(normalizedTitle, candidate);
  }

  return Array.from(byUrl.values()).sort((a, b) => b.publishedAt.getTime() - a.publishedAt.getTime());
}

export async function fetchNewsApiArticles(): Promise<RawArticle[]> {
  if (!NEWS_API_KEY) {
    logger.warn("NEWS_API_KEY not set, skipping NewsAPI fetch");
    return [];
  }

  const articles: RawArticle[] = [];

  for (const keyword of CREDIT_KEYWORDS.slice(0, 5)) {
    try {
      const params = new URLSearchParams({
        q: keyword,
        language: "en",
        sortBy: "publishedAt",
        pageSize: "10",
        apiKey: NEWS_API_KEY,
      });

      const response = await fetch(`${NEWS_API_URL}?${params}`);
      if (!response.ok) {
        logger.warn({ keyword, status: response.status }, "NewsAPI request failed");
        continue;
      }

      const data = (await response.json()) as {
        articles?: Array<{
          title: string;
          source?: { name?: string };
          publishedAt: string;
          url: string;
          content?: string;
          description?: string;
        }>;
      };

      for (const article of data.articles ?? []) {
        if (!article.title || article.title === "[Removed]" || !article.url) continue;
        const rawContent = article.content ?? article.description ?? null;
        if (looksLowQuality(article.title, rawContent) || !isCreditRelated(article.title, rawContent)) continue;

        articles.push({
          title: article.title,
          source: article.source?.name ?? "Unknown",
          publishedAt: new Date(article.publishedAt),
          url: article.url,
          rawContent,
        });
      }

      await new Promise((resolve) => setTimeout(resolve, 200));
    } catch (err) {
      logger.error({ err, keyword }, "Error fetching from NewsAPI");
    }
  }

  return dedupeArticles(articles);
}

export async function fetchRssArticles(): Promise<RawArticle[]> {
  const RSS_FEEDS = [
    { url: "https://feeds.a.dj.com/rss/RSSMarketsMain.xml", source: "Wall Street Journal" },
    { url: "https://rss.nytimes.com/services/xml/rss/nyt/Business.xml", source: "New York Times" },
    { url: "https://feeds.content.dowjones.io/public/rss/mw_topstories", source: "MarketWatch" },
    { url: "https://www.investing.com/rss/news_25.rss", source: "Investing.com" },
    { url: "https://search.cnbc.com/rs/search/combinedcms/view.xml?partnerId=wrss01&id=10001147", source: "CNBC" },
  ];

  const articles: RawArticle[] = [];

  for (const feed of RSS_FEEDS) {
    try {
      const response = await fetch(feed.url, {
        headers: { "User-Agent": "CreditIntelligenceDashboard/1.0" },
        signal: AbortSignal.timeout(5000),
      });

      if (!response.ok) continue;

      const text = await response.text();
      const items = text.match(/<item[\s\S]*?<\/item>/g) ?? [];

      for (const item of items.slice(0, 12)) {
        const titleMatch = item.match(/<title[^>]*><!\[CDATA\[([\s\S]*?)\]\]><\/title>|<title[^>]*>([\s\S]*?)<\/title>/);
        const linkMatch = item.match(/<link[^>]*>([\s\S]*?)<\/link>|<link[^>]*href="([^"]+)"/);
        const dateMatch = item.match(/<pubDate>([\s\S]*?)<\/pubDate>/);
        const descMatch = item.match(/<description[^>]*><!\[CDATA\[([\s\S]*?)\]\]><\/description>|<description[^>]*>([\s\S]*?)<\/description>/);

        const title = (titleMatch?.[1] ?? titleMatch?.[2] ?? "").trim();
        const link = (linkMatch?.[1] ?? linkMatch?.[2] ?? "").trim();
        const pubDate = (dateMatch?.[1] ?? "").trim();
        const description = (descMatch?.[1] ?? descMatch?.[2] ?? "").trim();

        if (!title || !link) continue;
        if (!isCreditRelated(title, description) || looksLowQuality(title, description)) continue;

        articles.push({
          title,
          source: feed.source,
          publishedAt: pubDate ? new Date(pubDate) : new Date(),
          url: link,
          rawContent: description || null,
        });
      }
    } catch (err) {
      logger.warn({ err, feed: feed.source }, "RSS feed fetch failed");
    }
  }

  return dedupeArticles(articles);
}
